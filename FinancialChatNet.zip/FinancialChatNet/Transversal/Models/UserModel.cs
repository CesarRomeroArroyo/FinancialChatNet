﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Transversal.Models
{
    public class UserModel
    {
        public int id { get; set; }

        public string email { get; set; }

        public string password { get; set; }
    }
}
